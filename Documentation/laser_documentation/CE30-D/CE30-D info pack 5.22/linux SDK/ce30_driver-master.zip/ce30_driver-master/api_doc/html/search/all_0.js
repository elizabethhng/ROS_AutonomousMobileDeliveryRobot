var searchData=
[
  ['_5fuse_5fmath_5fdefines',['_USE_MATH_DEFINES',['../packet_8cpp.html#a525335710b53cb064ca56b936120431e',1,'packet.cpp']]]
];
