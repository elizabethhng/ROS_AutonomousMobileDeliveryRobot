var searchData=
[
  ['unequal_5fbuffer_5fsize',['unequal_buffer_size',['../udp__socket_8h.html#ac339ae70bf477b4f427eed421cea56da',1,'udp_socket.h']]],
  ['unexcepted_5fpacket_5fsize',['unexcepted_packet_size',['../udp__socket_8h.html#a41cee240516bb75c8ca6c7c78cb0c7ca',1,'udp_socket.h']]]
];
