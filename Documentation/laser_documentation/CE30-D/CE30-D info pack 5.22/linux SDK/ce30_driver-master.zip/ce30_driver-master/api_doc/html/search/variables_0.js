var searchData=
[
  ['amplitude',['amplitude',['../structce30__driver_1_1_channel.html#adfb2c2e710f70979796ef7af43f0cb97',1,'ce30_driver::Channel']]],
  ['azimuth',['azimuth',['../structce30__driver_1_1_column.html#a7da7246ba6f3d0d83b7f5288c9cf20d0',1,'ce30_driver::Column']]]
];
