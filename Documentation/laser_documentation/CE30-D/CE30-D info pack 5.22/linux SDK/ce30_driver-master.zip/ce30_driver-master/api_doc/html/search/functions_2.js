var searchData=
[
  ['distancemax',['DistanceMax',['../structce30__driver_1_1_channel.html#ae4b872bd7d125658f1e56c17b8932091',1,'ce30_driver::Channel::DistanceMax()'],['../classce30__driver_1_1_scan.html#afc5f8c0101a085734eac8c55350ab0ff',1,'ce30_driver::Scan::DistanceMax()']]],
  ['distancemin',['DistanceMin',['../structce30__driver_1_1_channel.html#a63c4f47275065cbc35b740f57ba49bc0',1,'ce30_driver::Channel::DistanceMin()'],['../classce30__driver_1_1_scan.html#a558ba4748d5a458856c6d713f7986b73',1,'ce30_driver::Scan::DistanceMin()']]]
];
