var searchData=
[
  ['no_5fprior_5fconnection',['no_prior_connection',['../udp__socket_8h.html#a63fbb5558996fef7b627d58d824b024a',1,'udp_socket.h']]],
  ['non_5fblock_5ferror',['non_block_error',['../udp__socket_8h.html#ad3616a663ba80adc262ceffe5c823b4a',1,'udp_socket.h']]]
];
