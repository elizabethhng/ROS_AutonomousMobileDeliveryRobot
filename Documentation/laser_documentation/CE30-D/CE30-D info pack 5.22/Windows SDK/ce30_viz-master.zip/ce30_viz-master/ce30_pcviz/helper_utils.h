#ifndef HELPER_UTILS_H
#define HELPER_UTILS_H

#include <string>

namespace ce30_pcviz {
std::string ToCoordinateString(const float& x, const float& y, const float& z);
} // namespace

#endif // HELPER_UTILS_H
