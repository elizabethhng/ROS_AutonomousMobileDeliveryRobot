#include "point_cloud_viewer.h"

PointCloudViewer::PointCloudViewer()
{

}

bool PointCloudViewer::Displaying() {
  return true;
}

void PointCloudViewer::Display() {

}
