#ifndef POINT_CLOUD_VIEWER_H
#define POINT_CLOUD_VIEWER_H


class PointCloudViewer
{
public:
  PointCloudViewer();
  bool Displaying();
  void Display();
};

#endif // POINT_CLOUD_VIEWER_H
