#include "ces_special.h"

CESSpecial::CESSpecial()
  : static_scene_()
{

}
