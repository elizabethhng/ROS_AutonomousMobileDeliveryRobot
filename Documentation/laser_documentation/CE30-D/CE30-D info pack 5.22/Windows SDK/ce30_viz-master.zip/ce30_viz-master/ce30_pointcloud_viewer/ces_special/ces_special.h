#ifndef CES_SPECIAL_H
#define CES_SPECIAL_H

#include "ces_static_scene.h"

class CESSpecial
{
public:
  CESSpecial();
private:
  CESStaticScene static_scene_;
};

#endif // CES_SPECIAL_H
